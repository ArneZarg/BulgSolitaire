//Arne Zargarian
//1218735
//Bulgarian Solitaire
//CSIS 139

//This program demonstrates Bulgarian Solitaire

import java.util.ArrayList;
import java.util.Random;
import java.util.Collections;

public class BulgarianSol {
	/*MAIN METHOD */
	public static void main(String[] args)
	{
		ArrayList<Integer> cards = new ArrayList<Integer>();//initializes ArrayList<Integer> cards
		playGame(cards);//call playGame function.
	}
	/* VOID INITGAME: takes an ArrayList of Integers and sets all the elements sum to 45,
	 * removes the zeros, and displays the first step of the piles of cards*/
	public static void initGame(ArrayList<Integer> cards)
	{
		Random randNum = new Random();
		int totalCards = 45;//total number of cards
		int numCardsInPile = 0;//initialize number of cards in the pile
		int sumOfCards = 0;//sum of cards, used to check if the elements
		//in the array list are equal to 45.
		do
		{
			int i = 0;//initialize the counter
			numCardsInPile = (randNum.nextInt(45));//the cards in the pile cannot be more than 45
			if(sumOfCards < totalCards)//if the sum of the cards is less than total cards
			{
				cards.add(i, numCardsInPile);//add a new random element in the index of the counter
				sumOfCards += cards.get(i);//add the new random element to the sum of cards
				i++;//increment the counter
			}
			else if(sumOfCards > totalCards)//if the sumOfCards is greater than the totalCards
			{
				sumOfCards -= cards.get(i);//subtract the newest element from the sumOfCards
				cards.remove(i);//remove the last element
				i--;//counter decreases
			}
		}while(sumOfCards != totalCards);//the loop will keep going as long as the total is NOT 45.
		
		for(int i = 0; i < cards.size(); i++)//for loop to search the ArrayList for zeros
		{
			if(cards.get(i) == 0)//if the element is 0
			{
				cards.remove(i);//remove it
				i--;//decrease the counter/index
			}
		}
		Collections.sort(cards, Collections.reverseOrder());//sort the card piles from largest to smallest
		System.out.println("INITIAL SETUP: " + cards);//Display the initial step
	}

	/*VOID NEXTSTEP: takes an ArrayList of Integers, removes zeros, and subtracts 1 card from each pile
	 * and takes them to a new pile*/
	public static void nextStep(ArrayList<Integer> cards)
	{
		int newPile = 0;//initialize newPile = 0 (different from index, it counts the element, not index)
		
		for(int i = 0; i < cards.size(); i++)//
		{
			if(cards.get(i) == 0)//if the element at index(i) = 0
			{
				cards.remove(i);//remove the element at the index
				i--;//decrease index --i
			} 
			else //else (not a zero element)
			{
				int next = cards.get(i)-1;//subtract 1 from the element at index
				cards.set(i, next);//set it at index
				newPile++;//add 1 to the counter (aka the new element/pile of cards)
			}
		}
		cards.add(newPile);//add the newPile to the ArrayList of Cards
		System.out.println(cards);//Display the new arrangement
	}
	
	/*VOID PLAYGAME: plays the whole game, ends the game when the pattern is 1,2,3,...k */
	public static void playGame(ArrayList<Integer> cards)
	{
		initGame(cards);//calls initGame function to start the game
		int placeHolder = 1;//place holder initializes to 1 (since that is the first number you ought to be looking for
		int finCounter = 0;//final counter initializes to 0
	
		for(int m = 0; m < 100000; m++)//initialize index, let it go 100000 times or any large number that will allow it to loop a lot
		{
			nextStep(cards);//does the next step each time the loop goes
			System.out.println(cards);//prints the cards post-next step
			
			for( int p = 0; p < cards.size(); p++)//nested for loop to search the array for the placeHolder
			{
				if(cards.get(p) == placeHolder)//if the pile is the place holder
				{
					placeHolder++;//increase the place holder
					finCounter++;//increase the final counter
				}
				else //else
				{
					placeHolder = 0;//reset placeHolder to 0
					finCounter = 0;//reset final counter to 0
				}
			}
			if(finCounter == cards.size())//if the final counter is the size of the Array List cards
			{
				m = m+1000000000;//increase m by a lot so it doesn't lag the program (optional, still gives same result without it)
				for(int i = 0; i < cards.size(); i++)//search for 0's (gets rid the empty piles)
				{
					if(cards.get(i) == 0)//if the pile (index) from the Array List is the element 0 (aka is it empty)
						{
							cards.remove(i);//remove that card
							i--;//decrease index
						}
				}
			System.out.println(cards);//prints the final assortment of cards
		  }
		}
	}
	
}